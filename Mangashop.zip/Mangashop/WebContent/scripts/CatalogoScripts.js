/**
 * 
 */
  
	$(document).ready(function()
	{
	 	var x = document.getElementById("liCatalogo");
	 	x.className='';
	 	x.classList.add("active");
	});

 