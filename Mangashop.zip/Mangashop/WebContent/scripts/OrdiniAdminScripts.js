/**
 * 
 */
  
	$(document).ready(function()
	{
	 	var x = document.getElementById("liOrdini");
	 	x.className='';
	 	x.classList.add("active");
	});

