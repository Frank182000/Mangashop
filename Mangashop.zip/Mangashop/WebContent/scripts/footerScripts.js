/**
 * 
 */
 
 function showChiSiamo()
 {
 	var chiSiamo=document.getElementById("chiSiamoDiv").style.display="block";
 	var Contattaci=document.getElementById("contattaciDiv").style.display="none";
 }
 
 function showContattaci()
 {
 	var chiSiamo=document.getElementById("chiSiamoDiv").style.display="none";
 	var Contattaci=document.getElementById("contattaciDiv").style.display="block";
 }