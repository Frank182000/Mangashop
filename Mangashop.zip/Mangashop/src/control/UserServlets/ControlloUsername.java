package control.UserServlets;


import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import java.io.*;


@WebServlet("/ControlloUsername")
public class ControlloUsername extends HttpServlet
{
	private static DataSource ds;
	static {
		try {
			Context initCtx = new InitialContext();
			Context envCtx = (Context) initCtx.lookup("java:comp/env");

			ds = (DataSource) envCtx.lookup("jdbc/storage");

		} catch (NamingException e) {
			System.out.println("Error:" + e.getMessage());
		}
	}
	private static final String TABLE_NAME = "cliente";
    private static final long serialVersionUID = 1L;


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {
        PrintWriter out = response.getWriter();
        String user_name=request.getParameter("uname"); //il valore di uname va in user_name per non usare la request ogni volta
        if(user_name!=null && (user_name.length()>4 && user_name.length()<17)) 
        {
        	
        	System.out.println("l'username qui e' "+user_name);
        	if(user_name.matches("^[0-9a-zA-Z]+$"))
        	{
	            
		        Connection connection = null;
				PreparedStatement preparedStatement = null;
		
				String searchSQL = "SELECT userid FROM " + TABLE_NAME
						+ "  WHERE userid=?";
		        try {
		        	
		        	connection = ds.getConnection();
					preparedStatement = connection.prepareStatement(searchSQL);
					preparedStatement.setString(1, user_name);
					ResultSet rs = preparedStatement.executeQuery();
		            
		            if (!rs.next()) {
		                out.println(""+user_name+" e' disponibile.");
		            }
		            else{
		            out.println(""+user_name+" e' gia' in uso.");
		            }
		            out.println();
					
		        } catch (Exception e) {
		            out.println("Error ->" + e.getMessage());
		        } finally {
		            out.close();
		        }
        	}
        	else
        	{
        		out.println(""+user_name+" non e' disponibile (carattere/i invalido/i).");
        	}
        }
        else
        {
        	out.println(""+user_name+" non e' disponibile (dimensione inferiore a 5 o maggiore a 16 caratteri).");
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {
        doGet(request, response);
    }

}