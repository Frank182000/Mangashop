package control.UserServlets;


import java.io.IOException;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.UserModels.UserBean;
import model.UserModels.UserDAO;

/**
 * Servlet che effettua il login dell'utente
 */
@WebServlet("/EditProfileServlet")
public class EditProfileServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		UserDAO dao = new UserDAO();
		
		String userid=request.getParameter("userid");
        String passid=request.getParameter("passid");
        String nome=request.getParameter("nome");
        String cognome=request.getParameter("cognome");
        String email=request.getParameter("email");
        String mobile=request.getParameter("mobile");

        UserBean product=new UserBean();
        product.setUsername(userid);
        product.setPassword(passid);
        product.setNome(nome);
        product.setCognome(cognome);
        product.setEmail(email);
        product.setTelefono(mobile);


        try {

            dao.doUpdate(product);
            
            request.getSession().setAttribute("passid", passid);
            request.getSession().setAttribute("nome", nome);
            request.getSession().setAttribute("cognome", cognome);
            request.getSession().setAttribute("email", email);
            request.getSession().setAttribute("mobile", mobile);
            
            System.out.println("password: "+request.getSession().getAttribute("passid"));
            System.out.println("email: "+request.getSession().getAttribute("email"));
            System.out.println("nome: "+request.getSession().getAttribute("nome"));
            System.out.println("cognome: "+request.getSession().getAttribute("cognome"));
            System.out.println("telefono: "+request.getSession().getAttribute("mobile"));
            
           
        } catch(Exception e)
        {
            System.out.print("doUpdate non riuscito"+"\n"+e);
        }

        response.sendRedirect(request.getContextPath()+"/index.jsp");


	}

}
