package control.UserServlets;

import model.PurchaseModels.ProductBean;
import model.PurchaseModels.ProductDAO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import com.google.gson.*;

@WebServlet("/LiveSearchServlet")
public class LiveSearchServlet extends HttpServlet
{
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {
        //prende il testo inserito nella barra di ricerca inviato tramite parametro
        String search = request.getParameter("q");

        ProductDAO dao = new ProductDAO();
        ArrayList<ProductBean> productsSearched = new ArrayList<>();
        try {
            productsSearched = dao.doSearch(search);
        } catch (Exception e) {
            System.out.println("doSearch non effettuato");
            e.printStackTrace();
        }

        	response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
        	 Gson object=new Gson();
             String jsonObject=object.toJson(productsSearched);
             response.getWriter().write(jsonObject);
             System.out.print(jsonObject);

    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {
        doGet(request, response);
    }

}