package control.UserServlets;


import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import java.io.*;


@WebServlet("/ContEmail")
public class ContEmail extends HttpServlet
{
	private static DataSource ds;
	static {
		try {
			Context initCtx = new InitialContext();
			Context envCtx = (Context) initCtx.lookup("java:comp/env");

			ds = (DataSource) envCtx.lookup("jdbc/storage");

		} catch (NamingException e) {
			System.out.println("Error:" + e.getMessage());
		}
	}
	private static final String TABLE_NAME = "cliente";
    private static final long serialVersionUID = 1L;


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {
        PrintWriter out = response.getWriter();
        String user_email=request.getParameter("uemail");
        if(user_email!=null) 
        {
        	
        	System.out.println("l'email qui e' "+user_email);
        	if(user_email.matches("^\\w+([\\.-]?\\w+)*@\\w+([\\.-]?\\w+)*(\\.\\w{2,3})+$"))
        	{
	            
		        Connection connection = null;
				PreparedStatement preparedStatement = null;
		
				String searchSQL = "SELECT email FROM " + TABLE_NAME
						+ "  WHERE email=?";
		        try {
		        	
		        	connection = ds.getConnection();
					preparedStatement = connection.prepareStatement(searchSQL);
					preparedStatement.setString(1, user_email);
					ResultSet rs = preparedStatement.executeQuery();
		            
		            if (!rs.next()) {
		                out.println(""+user_email+" e' disponibile.");
		            }
		            else{
		            out.println(""+user_email+" e' gia' in uso.");
		            }
		            out.println();
					
		        } catch (Exception e) {
		            out.println("Error ->" + e.getMessage());
		        } finally {
		            out.close();
		        }
        	}
        	else
        	{
        		out.println(""+user_email+" non e' disponibile (non rispetta la sintassi delle email).");
        	}
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {
        doGet(request, response);
    }

}