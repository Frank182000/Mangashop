package control.AdminServlets;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import control.AdminServlets.ImageUpload.FilePart;
import model.PurchaseModels.ProductBean;
import model.PurchaseModels.ProductDAO;
import java.sql.Date;

//Servlet che modifica il prodotto ricevuto da ModifyProduct.jsp

@MultipartConfig
@WebServlet("/ModifyProductServlet")
public class ModifyProductServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;


    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {
        doPost(request, response);

    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {
        ProductDAO dao = new ProductDAO();
        String idManga = request.getParameter("idProdotto");
        String oldTitle=""; 
        try
        {
        	
            ProductBean temp=dao.doRetrieveByKey(Integer.parseInt(idManga));
            oldTitle=temp.getNomeProdotto();
        }
        catch(Exception e)
        {
            System.out.print("doRetrieve non riuscito"+e);
        }



        //Eliminazione prodotto dal database da parte dell'admin richiesta da ModifyProduct.jsp
        if(request.getParameter("elimina")!=null)
        {
            try
            {
                dao.doDelete(Integer.parseInt(idManga));
                response.sendRedirect(request.getContextPath()+"/adminPages/Catalogo.jsp");

            } catch(Exception e)
            {
                System.out.print("doDelete non riuscito"+"\n"+e);
            }
            return;
        }

        String disponibilit�=request.getParameter("disponibilit�");
        String nomeProdotto=request.getParameter("nomeProdotto");
        String categoria=request.getParameter("categoria");
        String prezzo=request.getParameter("prezzo");
        String iva=request.getParameter("iva");
        String inCatalogo=request.getParameter("inCatalogo");
        String lingua=request.getParameter("lingua");     
        String descrizione=request.getParameter("descrizione");
        String data=request.getParameter("data");
        String editore=request.getParameter("editore");

        System.out.println(inCatalogo);
        boolean isInCatalogo=false;
        if(inCatalogo.equals("si"))
        {
        	isInCatalogo=true;
        }
        

        Date date=Date.valueOf(data);//converto la stringa data in un sql.Date
        //metto tutte le lingue in un'unica stringa


        ProductBean product=new ProductBean();
        product.setIdProdotto(Integer.parseInt(idManga));
        product.setDisponibilita(Integer.parseInt(disponibilit�));
        product.setNomeProdotto(nomeProdotto);
        product.setCategoria(categoria);
        product.setPrezzo(Double.parseDouble(prezzo));
        product.setIva(Double.parseDouble(iva));
        product.setInCatalogo(isInCatalogo);
        product.setLingua(lingua);
        product.setDescrizione(descrizione);
        product.setDataPubblicazione(date);
        product.setEditore(editore);


        try {

            /*
             * 1- Se il titolo � cambiato ma non � richiesto il cambio di copertina, basta rinominare la cartella
             * 2- Se il titolo � cambiato e c'� una nuova copertina, si elimina la cartella precendete e se ne crea una nuova in cui
             * caricare l'immagine
             * 3- Se il titolo � lo stesso ma cambia la copertina, si elimina la copertina vecchia e si aggiunge la nuova
             * */

            dao.doUpdate(product);
            Part filePart = request.getPart("copertina");
            final String imagesPath="C:\\Users\\User\\Desktop\\Presentazione Finale\\Mangashop\\WebContent\\images";

            //1
            if(oldTitle.equals(nomeProdotto)==false && filePart.getSize()<=0)
            {
                System.out.println("1");
                String oldFolderName=imagesPath+"\\"+oldTitle;
                String newFolderName=imagesPath+"\\"+nomeProdotto;
                File oldDir = new File(oldFolderName);
                File newDir = new File(newFolderName);
                oldDir.renameTo(newDir);

            }
            //2
            else if(oldTitle.equals(nomeProdotto)==false && filePart.getSize()>0)
            {
                System.out.println("2");
                String fileName = FilePart.getSubmittedFileName(filePart);
                InputStream fileContent = filePart.getInputStream();
                //Ne ricavo l'estensione per creare correttamente il FileOutputStream
                String extension=fileName.substring(fileName.lastIndexOf("."));

                String folderName;
                folderName=imagesPath+"\\"+nomeProdotto;
                String toDelete=imagesPath+"\\"+oldTitle;
                new File(folderName).mkdirs();//crea una nuova cartella



                //Creo il nuovo file in cui copiare l'immagine
                String outputName=folderName+"\\copertina"+extension;
                OutputStream output=new FileOutputStream(outputName);
                fileContent.transferTo(output);
                output.close();
                fileContent.close();

                //cancello la cartella vecchia e tutto il suo contenuto
                File toDeleteFile= new File(toDelete);
                String[]entries = toDeleteFile.list();
                for(String s: entries){
                    File currentFile = new File(toDeleteFile.getPath(),s);
                    currentFile.delete();
                }
                toDeleteFile.delete();


            }
            else if(oldTitle.equals(nomeProdotto) && filePart.getSize()>0)
            {
                System.out.println("3");
                String fileName = FilePart.getSubmittedFileName(filePart);
                InputStream fileContent = filePart.getInputStream();
                //Ne ricavo l'estensione per creare correttamente il FileOutputStream
                String extension=fileName.substring(fileName.lastIndexOf("."));

                String folderName;
                folderName=imagesPath+"\\"+nomeProdotto;

                //Creo il nuovo file in cui copiare l'immagine
                String outputName=folderName+"\\copertina"+extension;
                OutputStream output=new FileOutputStream(outputName, false); //sovrascrive il file
                fileContent.transferTo(output);
                output.close();
                fileContent.close();
            }

        } catch(Exception e)
        {
            System.out.print("doUpdate non riuscito"+"\n"+e);
        }


        //ridizionare alla stessa pagina di modifica del prodotto? da decidere
        response.sendRedirect(request.getContextPath()+"/adminPages/Catalogo.jsp");



    }

}