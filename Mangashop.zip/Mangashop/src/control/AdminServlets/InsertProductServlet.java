package control.AdminServlets;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import control.AdminServlets.ImageUpload.FilePart;
import model.PurchaseModels.ProductBean;
import model.PurchaseModels.ProductDAO;
import java.sql.Date;

@MultipartConfig 
@WebServlet("/InsertProductServlet")
public class InsertProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
			
			String disponibilit�=request.getParameter("disponibilit�");
	        String nomeProdotto=request.getParameter("nome");
	        String categoria=request.getParameter("categoria");
	        String prezzo=request.getParameter("prezzo");
	        String iva=request.getParameter("iva");
	        String lingua=request.getParameter("lingua");
	        String descrizione=request.getParameter("descrizione");
	        String data=request.getParameter("data");
	        String editore=request.getParameter("editore");

			Date date=Date.valueOf(data);//converto la stringa data in un sql.Date
			//metto tutte le lingue e i sottotitoli in un'unica stringa
			
			
			ProductBean product=new ProductBean();
	        product.setDisponibilita(Integer.parseInt(disponibilit�));
	        product.setNomeProdotto(nomeProdotto);
	        System.out.println(nomeProdotto+" poi l'altro coso "+product.getNomeProdotto());
	        product.setCategoria(categoria);
	        product.setPrezzo(Double.parseDouble(prezzo));
	        product.setIva(Double.parseDouble(iva));
	        product.setLingua(lingua);
	        product.setDescrizione(descrizione);
	        product.setDataPubblicazione(date);
	        product.setEditore(editore);
			
			ProductDAO dao=new ProductDAO();
			try
			{
				dao.doSave(product);
				
				/*Viene presa la copertina e inserita sul server*/

				//Metto in un InputStream l'immagine
			    Part copertina = request.getPart("copertina");
			    String copertinaFileName = FilePart.getSubmittedFileName(copertina);
			    InputStream copertinafileContent = copertina.getInputStream();
			    
			    //Ne ricavo l'estensione per creare correttamente il FileOutputStream
			    String extension1=copertinaFileName.substring(copertinaFileName.lastIndexOf("."));
			    
			    //Creo la cartella in cui verr� inserita l'immagine nel server
			    final String imagesPath="C:\\Users\\User\\Desktop\\Presentazione Finale\\Mangashop\\WebContent\\images";
				/*Non si pu� caricare un file sul server specificando l'URL, bisogna specificare il path vero e proprio.
				 * Quando ci lavoriamo, mettiamo la precedente stringa tra commenti e cambiamo il path*/
			    
			    String folderName=imagesPath+"\\"+nomeProdotto; 
			    new File(folderName).mkdirs();//crea una nuova cartella
			    
			    //Creo il nuovo file in cui copiare l'immagine
			     String outCopertina=folderName+"\\copertina"+extension1;

			     OutputStream outputCopertina=new FileOutputStream(outCopertina);

			     copertinafileContent.transferTo(outputCopertina);


			     outputCopertina.close();

			}
			catch(Exception e)
			{
				System.out.print("doSave non riuscito"+"\n"+e);
			}
			
			
			response.sendRedirect("adminPages/Catalogo.jsp");
			
	}

}
