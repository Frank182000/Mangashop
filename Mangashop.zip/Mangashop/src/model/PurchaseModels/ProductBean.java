
package model.PurchaseModels;

import java.sql.Date;

public class ProductBean 
{
	int idProdotto;
	int disponibilit�;
	String nomeProdotto;
	String categoria;
	double prezzo;
	double iva;
	boolean inCatalogo;
	String lingua;
	String descrizione;
	Date dataPubblicazione;
	String editore;
	int numeroVendite;
	
	
	
	//GETS
	public double getPrezzoTotale()
	{
		double prezzoIva=prezzo + ((prezzo*iva)/100);
		double val=Math.floor(prezzoIva * 100) / 100;
		return val;
	}
	
	public boolean getInCatalogo()
	{
		return inCatalogo;
	}
	
	public int getIdProdotto()
	{
		return idProdotto;
	}
	
	public String getNomeProdotto() 
	{
		return nomeProdotto;
	}
	
	public String getDescrizione()
	{
		return descrizione;
	}
	
	public String getCategoria() 
	{
		return categoria;
	}
	
	public double getPrezzo()
	{
		return Math.floor(prezzo * 100) / 100;
	}
	
	public double getIva()
	{
		return iva;
	}
	
	public int getDisponibilita()
	{
		return disponibilit�;
	}
	
	public String getLingua()
	{
		return lingua;
	}
	
	public Date getDataPubblicazione()
	{
		return dataPubblicazione;
	}
	
	public String getEditore()
	{
		return editore;
	}
	public int getNumeroVendite() 
	{
		return numeroVendite;
	}
	

	
	
	//SETS
	public void setInCatalogo(boolean value)
	{
		inCatalogo=value;
	}

	public void setIdProdotto(int newidProdotto)
	{
		idProdotto=newidProdotto;
	}
	
	public void setNomeProdotto(String newnomeProdotto) 
	{
		nomeProdotto=newnomeProdotto;
	}
	
	public void setDescrizione(String newDescrizione)
	{
		descrizione=newDescrizione;
	}
	
	public void setCategoria(String newCategoria) 
	{
		categoria=newCategoria;
	}
	
	public void setPrezzo(double newPrezzo) 
	{
		prezzo=newPrezzo;
	}
	
	public void setIva(double newIva)
	{
		iva=newIva;
	}

	public void setDisponibilita(int newDisponibilita)
	{
		disponibilit�=newDisponibilita;
	}
	
	public void setLingua(String newLingua)
	{
		lingua=newLingua;
	}
	
	public void setEditore(String newEditore)
	{
		editore=newEditore;
	}
	
	public void setDataPubblicazione(Date newDataPubblicazione)
	{
		dataPubblicazione=newDataPubblicazione;
	}
	
	public void setNumeroVendite(int newNumeroVendite) 
	{
		numeroVendite=newNumeroVendite;
	}
}
