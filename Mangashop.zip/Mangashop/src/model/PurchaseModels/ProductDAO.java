package model.PurchaseModels;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;


public class ProductDAO 
{
	private static DataSource ds;

	static {
		try {
			Context initCtx = new InitialContext();
			Context envCtx = (Context) initCtx.lookup("java:comp/env");

			ds = (DataSource) envCtx.lookup("jdbc/storage");

		} catch (NamingException e) {
			System.out.println("Error:" + e.getMessage());
		}
	}

	private static final String TABLE_NAME = "prodotto";
	
	public synchronized void doSave(ProductBean product) throws SQLException, Exception {

		Connection connection = null;
		PreparedStatement preparedStatement = null;

		String insertSQL = "INSERT INTO " + TABLE_NAME
				+ " (disponibilit�, nomeProdotto, categoria,"
				+ "  prezzo, iva, lingua, descrizione, dataPubblicazione, editore) "
				+ "  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(insertSQL);
			preparedStatement.setInt(1, product.getDisponibilita());
			preparedStatement.setString(2, product.getNomeProdotto());
			preparedStatement.setString(3, product.getCategoria());
			preparedStatement.setDouble(4, product.getPrezzo());
			preparedStatement.setDouble(5, product.getIva());
			//preparedStatement.setBoolean(6, product.getInCatalogo());
			preparedStatement.setString(6, product.getLingua());
			preparedStatement.setString(7, product.getDescrizione());
			preparedStatement.setDate(8, product.getDataPubblicazione());
			preparedStatement.setString(9, product.getEditore());
			
			preparedStatement.executeUpdate();

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
	}

	//Modifica la quantita in negozio e il numero di vendite del prodotto in base al numero di copie acquistate
	@SuppressWarnings("resource")
	public synchronized void doUpdateProduct(ProductBeanCart product) throws SQLException, Exception {

		Connection connection = null;
		PreparedStatement preparedStatement = null;


		try {
			connection = ds.getConnection();

			String selectSQL = "SELECT disponibilit�,numeroVendite FROM " + TABLE_NAME + " WHERE idProdotto = ?";
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setInt(1, product.getIdProdotto());
			System.out.println("id: " + product.getIdProdotto());
			ResultSet rs = preparedStatement.executeQuery();
			rs.next();

			int vendite = rs.getInt("numeroVendite");
			int quantita = rs.getInt("disponibilit�");

			quantita -= product.getCartQuantity();
			System.out.println("car" + product.getCartQuantity());
			vendite += product.getCartQuantity();

			String updateSQL = "UPDATE " + TABLE_NAME
						+ " SET numeroVendite= ?, disponibilit�= ? "
						+ " WHERE idProdotto = ?";

			preparedStatement = connection.prepareStatement(updateSQL);
			preparedStatement.setInt(1, vendite);
			preparedStatement.setInt(2, quantita);
			preparedStatement.setInt(3, product.getIdProdotto());

			preparedStatement.executeUpdate();

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
	}


	public synchronized ProductBean doRetrieveByKey(int code) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		ProductBean bean = new ProductBean();

		String selectSQL = "SELECT * FROM " +TABLE_NAME + " WHERE idProdotto = ?";

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setInt(1, code);

			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				bean.setIdProdotto(rs.getInt("idProdotto"));
				bean.setDisponibilita(rs.getInt("disponibilit�"));
				bean.setNomeProdotto(rs.getString("nomeProdotto"));
				bean.setCategoria(rs.getString("categoria"));
				bean.setPrezzo(rs.getDouble("prezzo"));
				bean.setIva(rs.getDouble("iva"));
				bean.setInCatalogo(rs.getBoolean("inCatalogo"));
				bean.setLingua(rs.getString("lingua"));
				bean.setDescrizione(rs.getString("descrizione"));
				bean.setDataPubblicazione(rs.getDate("dataPubblicazione"));
				bean.setEditore(rs.getString("editore"));
				bean.setNumeroVendite(rs.getInt("numeroVendite"));
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return bean;
	}

	public synchronized ArrayList<ProductBean> doRetrieveByGenre(String genre) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		ArrayList<ProductBean> products = new ArrayList<>();

		String selectSQL = "SELECT * FROM " +TABLE_NAME + " WHERE categoria = '"+genre+"'";

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);

			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				ProductBean bean = new ProductBean();

				bean.setIdProdotto(rs.getInt("idProdotto"));
				bean.setNomeProdotto(rs.getString("nomeProdotto"));
				bean.setCategoria(rs.getString("categoria"));
				bean.setPrezzo(rs.getDouble("prezzo"));
				bean.setIva(rs.getDouble("iva"));
				bean.setDisponibilita(rs.getInt("disponibilit�"));
				bean.setLingua(rs.getString("lingua"));
				bean.setEditore(rs.getString("editore"));
				bean.setDataPubblicazione(rs.getDate("dataPubblicazione"));
				bean.setInCatalogo(rs.getBoolean("inCatalogo"));
				bean.setDescrizione(rs.getString("descrizione"));
				bean.setNumeroVendite(rs.getInt("numeroVendite"));

				products.add(bean);
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return products;
	}

	public synchronized ArrayList<ProductBean> doRetrieveByNumeroVendite() throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		ArrayList<ProductBean> products = new ArrayList<>();

		String selectSQL = "SELECT * FROM " +TABLE_NAME + " ORDER BY numeroVendite DESC";

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);


			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				ProductBean bean = new ProductBean();

				bean.setIdProdotto(rs.getInt("idProdotto"));
				bean.setNomeProdotto(rs.getString("nomeProdotto"));
				bean.setCategoria(rs.getString("categoria"));
				bean.setPrezzo(rs.getDouble("prezzo"));
				bean.setIva(rs.getDouble("iva"));
				bean.setDisponibilita(rs.getInt("disponibilit�"));
				bean.setLingua(rs.getString("lingua"));
				bean.setEditore(rs.getString("editore"));
				bean.setDataPubblicazione(rs.getDate("dataPubblicazione"));
				bean.setInCatalogo(rs.getBoolean("inCatalogo"));
				bean.setDescrizione(rs.getString("descrizione"));
				bean.setNumeroVendite(rs.getInt("numeroVendite"));
				
				products.add(bean);
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return products;
	}

	public synchronized ArrayList<ProductBean> doRetrieveByPrice() throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		ArrayList<ProductBean> products = new ArrayList<>();

		String selectSQL = "SELECT * FROM " +TABLE_NAME + " ORDER BY prezzo ASC";

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);


			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				ProductBean bean = new ProductBean();

				bean.setIdProdotto(rs.getInt("idProdotto"));
				bean.setNomeProdotto(rs.getString("nomeProdotto"));
				bean.setCategoria(rs.getString("categoria"));
				bean.setPrezzo(rs.getDouble("prezzo"));
				bean.setIva(rs.getDouble("iva"));
				bean.setDisponibilita(rs.getInt("disponibilit�"));
				bean.setLingua(rs.getString("lingua"));
				bean.setEditore(rs.getString("editore"));
				bean.setDataPubblicazione(rs.getDate("dataPubblicazione"));
				bean.setInCatalogo(rs.getBoolean("inCatalogo"));
				bean.setDescrizione(rs.getString("descrizione"));
				bean.setNumeroVendite(rs.getInt("numeroVendite"));

				products.add(bean);
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return products;
	}

	public synchronized ArrayList<ProductBean> doRetrieveByDateDESC() throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		ArrayList<ProductBean> products = new ArrayList<>();

		String selectSQL = "SELECT * FROM " +TABLE_NAME + " ORDER BY dataPubblicazione DESC";

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);

			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				ProductBean bean = new ProductBean();

				bean.setIdProdotto(rs.getInt("idProdotto"));
				bean.setNomeProdotto(rs.getString("nomeProdotto"));
				bean.setCategoria(rs.getString("categoria"));
				bean.setPrezzo(rs.getDouble("prezzo"));
				bean.setIva(rs.getDouble("iva"));
				bean.setDisponibilita(rs.getInt("disponibilit�"));
				bean.setLingua(rs.getString("lingua"));
				bean.setEditore(rs.getString("editore"));
				bean.setDataPubblicazione(rs.getDate("dataPubblicazione"));
				bean.setInCatalogo(rs.getBoolean("inCatalogo"));
				bean.setDescrizione(rs.getString("descrizione"));
				bean.setNumeroVendite(rs.getInt("numeroVendite"));

				products.add(bean);
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return products;
	}

	public synchronized boolean doDelete(int code) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		int result = 0;
		
		/*Se un prodotto viene eliminato, l'utente deve poter vedere nei suoi ordini il prodotto
		 * se l'ha precedentemente acquistato. Per fare questo, non cancelliamo la riga dal DB, ma settiamo
		 * inCatalogo a false per mantenere le informazioni sul prodotto e allo stesso tempo, non mostrarlo 
		 * nel Catalogo*/
		String deleteSQL="update " + TABLE_NAME + " set inCatalogo=false, disponibilit�=0 where idProdotto= ?";
		
		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(deleteSQL);
			preparedStatement.setInt(1, code);

			result = preparedStatement.executeUpdate();

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return (result != 0);
	}

	
	public synchronized ArrayList<ProductBean> doRetrieveAll(String order) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		ArrayList<ProductBean> products = new ArrayList<ProductBean>();

		String selectSQL = "SELECT * FROM " + TABLE_NAME;

		if (order != null && !order.equals("")) {
			selectSQL += " ORDER BY " + order;
		}

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);

			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				ProductBean bean = new ProductBean();

				bean.setIdProdotto(rs.getInt("idProdotto"));
				bean.setDisponibilita(rs.getInt("disponibilit�"));
				bean.setNomeProdotto(rs.getString("nomeProdotto"));
				bean.setCategoria(rs.getString("categoria"));
				bean.setPrezzo(rs.getDouble("prezzo"));
				bean.setIva(rs.getDouble("iva"));
				bean.setInCatalogo(rs.getBoolean("inCatalogo"));
				bean.setDescrizione(rs.getString("descrizione"));
				bean.setLingua(rs.getString("lingua"));
				bean.setEditore(rs.getString("editore"));
				bean.setDataPubblicazione(rs.getDate("dataPubblicazione"));
				bean.setNumeroVendite(rs.getInt("numeroVendite"));
				
				products.add(bean);
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return products;
	}

	public synchronized void doUpdate(ProductBean product) throws SQLException, Exception {

		Connection connection = null;
		PreparedStatement preparedStatement = null;

		String insertSQL = "UPDATE " + TABLE_NAME
				+ " SET disponibilit�=?, nomeProdotto=?, categoria=?, prezzo=?, iva=?,"
				+ " inCatalogo=?, lingua=?, descrizione=?, dataPubblicazione=?, editore=?  WHERE idProdotto = ?";

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(insertSQL);
			preparedStatement.setInt(1, product.getDisponibilita());
			preparedStatement.setString(2, product.getNomeProdotto());
			preparedStatement.setString(3, product.getCategoria());
			preparedStatement.setDouble(4, product.getPrezzo());
			preparedStatement.setDouble(5, product.getIva());
			preparedStatement.setBoolean(6, product.getInCatalogo());
			preparedStatement.setString(7, product.getLingua());
			preparedStatement.setString(8, product.getDescrizione());
			preparedStatement.setDate(9, product.getDataPubblicazione());
			preparedStatement.setString(10, product.getEditore());
			preparedStatement.setInt(11, product.getIdProdotto());

			preparedStatement.executeUpdate();

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
	}

	public synchronized ArrayList<ProductBean> doSearch(String product) throws SQLException, Exception {

		Connection connection = null;
		PreparedStatement preparedStatement = null;

		String searchSQL = "SELECT * FROM " + TABLE_NAME
				+ "  WHERE nomeProdotto LIKE ?";

		ArrayList<ProductBean> products = new ArrayList<ProductBean>();

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(searchSQL);

			preparedStatement.setString(1, product+"%");
			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next())
			{
				ProductBean bean = new ProductBean();

				bean.setIdProdotto(rs.getInt("idProdotto"));
				bean.setNomeProdotto(rs.getString("nomeProdotto"));
				bean.setCategoria(rs.getString("categoria"));
				bean.setPrezzo(rs.getDouble("prezzo"));
				bean.setIva(rs.getDouble("iva"));
				bean.setDisponibilita(rs.getInt("disponibilit�"));
				bean.setDescrizione(rs.getString("descrizione"));
				bean.setLingua(rs.getString("lingua"));
				bean.setEditore(rs.getString("editore"));
				bean.setDataPubblicazione(rs.getDate("dataPubblicazione"));
				bean.setInCatalogo(rs.getBoolean("inCatalogo"));
				bean.setNumeroVendite(rs.getInt("numeroVendite"));
				
				products.add(bean);
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}

		return products;
	}


}