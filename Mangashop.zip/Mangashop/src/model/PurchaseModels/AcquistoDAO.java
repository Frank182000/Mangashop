package model.PurchaseModels;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import java.sql.Date;
public class AcquistoDAO 
{
	private static DataSource ds;

	static {
		try {
			Context initCtx = new InitialContext();
			Context envCtx = (Context) initCtx.lookup("java:comp/env");

			ds = (DataSource) envCtx.lookup("jdbc/storage");

		} catch (NamingException e) {
			System.out.println("Error:" + e.getMessage());
		}
	}

	private static final String TABLE_NAME = "acquisto";
	private static final String TABLE_NAME2 = "composto";
	
	public synchronized void doSave(AcquistoBean acquisto) throws SQLException, Exception 
	{

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		PreparedStatement preparedStatement2 = null;
		PreparedStatement preparedStatement3 = null;
		
		String insertSQL = "INSERT INTO " + TABLE_NAME
				+ " (prezzo, stato, dataOrdine,"
				+ "  userid, via, numCivico, cap, citta, provincia) "
				+ "  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
		
		String insertSQL2 = "INSERT INTO " + TABLE_NAME2
						+ "(acquisto, idProdotto, disponibilit�, "
						+ "ivaProdotto, prezzoProdotto) VALUES "
						+ "(?, ?, ?, ?, ?)";
		
		String maxId= "select max(numeroOrdine) as massimo from " + TABLE_NAME;
		
		

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(insertSQL);
			preparedStatement.setDouble(1, acquisto.getPrezzo());
			preparedStatement.setString(2, acquisto.getStato());
			preparedStatement.setDate(3, acquisto.getDataOrdine());
			preparedStatement.setString(4, acquisto.getUtente());
			preparedStatement.setString(5, acquisto.getIndirizzo());
			preparedStatement.setInt(6, acquisto.getNumCivico());
			preparedStatement.setInt(7, acquisto.getCap());
			preparedStatement.setString(8, acquisto.getCitta());
			preparedStatement.setString(9, acquisto.getProvincia());
			
			if(preparedStatement.executeUpdate()==1)
			{
				preparedStatement3=connection.prepareStatement(maxId);
				ResultSet set=preparedStatement3.executeQuery();
				set.next();
				
				int numeroOrdine=set.getInt("massimo");
				ArrayList<ProductBeanCart> prodotti=acquisto.getProdotti();
				preparedStatement2=connection.prepareStatement(insertSQL2);
				
				for(int i=0; i<prodotti.size(); i++)
				{
					ProductBeanCart prodotto=prodotti.get(i);
					
					
					preparedStatement2.setInt(1, numeroOrdine);
					preparedStatement2.setInt(2, prodotto.getIdProdotto());
					preparedStatement2.setInt(3, prodotto.getCartQuantity());
					preparedStatement2.setDouble(4, prodotto.getIva());
					preparedStatement2.setDouble(5, prodotto.getPrezzo());
					
					preparedStatement2.executeUpdate();	
				}		
			}

			} 
			finally 
			{
				try 
				{
					if (preparedStatement != null)
						preparedStatement.close();
					
					if (preparedStatement2 != null)
						preparedStatement.close();
					
					if (preparedStatement3 != null)
						preparedStatement.close();
				} 
				finally 
				{
					if (connection != null)
						connection.close();
				}
			}
	}	

	
	/*
	 * Restituisce tutti gli ordini di un utente in base all'username*/
	public synchronized ArrayList<AcquistoBean> doRetrieveByUser(String user) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		PreparedStatement preparedStatement2 = null;
		
		ArrayList<AcquistoBean> arrayBean = new ArrayList<AcquistoBean>();
		boolean rows=false; //controlla se la query ha restituito delle righe
		
		String TB="prodotto"; //nome tabella con cui fare join
		
		String selectSQL = "SELECT numeroOrdine, prezzo, stato, "
				+ "dataOrdine, userid, via, numCivico, cap, citta, provincia from " 
				+ TABLE_NAME + " where userid= ?";
				
		String selectSQL2 = "SELECT T1.disponibilit�, ivaProdotto, "
				+  "prezzoProdotto, T1.idProdotto, nomeProdotto, editore FROM "
				+ TABLE_NAME2 + " as T1 inner join " + TB + " as T2 on "
				+ "T1.idProdotto = T2.idProdotto where acquisto= ?";
		

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setString(1, user);
			preparedStatement2 = connection.prepareStatement(selectSQL2);
			
			ResultSet rs = preparedStatement.executeQuery();
			
			while (rs.next()) {
				rows=true;
				AcquistoBean bean=new AcquistoBean();
				bean.setUtente(rs.getString("userid"));
				bean.setNumeroOrdine(rs.getInt("numeroOrdine"));
				bean.setPrezzo(rs.getDouble("prezzo"));
				bean.setStato(rs.getString("stato"));
				bean.setIndirizzo(rs.getString("via"));
				bean.setDataOrdine(rs.getDate("dataOrdine"));
				bean.setNumCivico(rs.getInt("numCivico"));
				bean.setCap(rs.getInt("cap"));
				bean.setCitta(rs.getString("citta"));
				bean.setProvicia(rs.getString("provincia"));
				
				ArrayList<ProductBeanCart> prodotti=new ArrayList<ProductBeanCart>();
				preparedStatement2.setInt(1, rs.getInt("numeroOrdine"));
				ResultSet rs2 = preparedStatement2.executeQuery();
				
				while(rs2.next())
				{
					ProductBeanCart prodotto=new ProductBeanCart();
					prodotto.setCartQuantity(rs2.getInt("disponibilit�"));
					prodotto.setIva(rs2.getDouble("ivaProdotto"));
					prodotto.setPrezzo(rs2.getDouble("prezzoProdotto"));
					prodotto.setIdProdotto(rs2.getInt("idProdotto"));
					prodotto.setNomeProdotto(rs2.getString("nomeProdotto"));
					
					prodotti.add(prodotto);
				}
				
				bean.setProdotti(prodotti);
				arrayBean.add(bean);
			}
	
			
		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		
		if(!rows)
		{
			return null;
		}
		return arrayBean;
	}
	
	public synchronized AcquistoBean doRetrieveByKey(int numeroOrdine) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		PreparedStatement preparedStatement2 = null;
		
		AcquistoBean bean = new AcquistoBean();

		String TB="prodotto"; //nome tabella con cui fare join

		String selectSQL = "SELECT numeroOrdine, prezzo, stato, "
				+ "dataOrdine, userid, via, numCivico, cap, citta, provincia from " + TABLE_NAME + " where numeroOrdine= ?";
				
		String selectSQL2 = "SELECT T1.disponibilit�, ivaProdotto, "
				+  "prezzoProdotto, T1.idProdotto, nomeProdotto, editore FROM "
				+ TABLE_NAME2 + " as T1 inner join " + TB + " as T2 on "
				+ "T1.idProdotto = T2.idProdotto where acquisto= ?";
		

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setInt(1, numeroOrdine);
			preparedStatement2 = connection.prepareStatement(selectSQL2);
			preparedStatement2.setInt(1, numeroOrdine);

			ResultSet rs = preparedStatement.executeQuery();
			ResultSet rs2 = preparedStatement2.executeQuery();
			
			if (rs.next()) {
				bean.setNumeroOrdine(rs.getInt("numeroOrdine"));
				bean.setPrezzo(rs.getDouble("prezzo"));
				bean.setStato(rs.getString("stato"));
				bean.setDataOrdine(rs.getDate("dataOrdine"));
				bean.setUtente(rs.getString("userid"));
				bean.setIndirizzo(rs.getString("via"));
				bean.setNumCivico(rs.getInt("numCivico"));
				bean.setCap(rs.getInt("cap"));
				bean.setCitta(rs.getString("citta"));
				bean.setProvicia(rs.getString("provincia"));
				
				ArrayList<ProductBeanCart> prodotti=new ArrayList<ProductBeanCart>();
				
				while(rs2.next())
				{
					ProductBeanCart prodotto=new ProductBeanCart();
					prodotto.setCartQuantity(rs2.getInt("disponibilit�"));
					prodotto.setIva(rs2.getDouble("ivaProdotto"));
					prodotto.setPrezzo(rs2.getDouble("prezzoProdotto"));
					prodotto.setIdProdotto(rs2.getInt("idProdotto"));
					prodotto.setNomeProdotto(rs2.getString("nomeProdotto"));
					
					prodotti.add(prodotto);
				}
				
				bean.setProdotti(prodotti);
			}
			else
			{
				return null;
			}
			
			

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return bean;
	}

	
	
	public synchronized boolean doDelete(int numeroOrdine) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		PreparedStatement preparedStatement2 = null;

		int result = 0;
		int result2 = 0;
		
		String deleteSQL = "DELETE FROM " + TABLE_NAME + " WHERE numeroOrdine = ?";
		String deleteSQL2 = "DELETE FROM " + TABLE_NAME2 + "WHERE acquisto = ?";

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(deleteSQL);
			preparedStatement2 = connection.prepareStatement(deleteSQL2);
			preparedStatement.setInt(1, numeroOrdine);
			preparedStatement2.setInt(1, numeroOrdine);
			
			

			result2 = preparedStatement2.executeUpdate();
			result = preparedStatement.executeUpdate();

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return (result != 0 && result2!=0);
	}

	//Ricava gli ordini che vanno da dataInizio fino a dataFine
	public synchronized ArrayList<AcquistoBean> doRetrieveFromDateToDate(Date dataInizio, Date dataFine) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		ArrayList<AcquistoBean> orders = new ArrayList<AcquistoBean>();

		String selectSQL = "SELECT * FROM " +TABLE_NAME+ " WHERE dataOrdine BETWEEN ? AND ?";

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setDate(1, dataInizio);
			preparedStatement.setDate(2, dataFine);

			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next())
			{
				int numeroOrdine=rs.getInt("numeroOrdine");
				AcquistoBean bean= doRetrieveByKey(numeroOrdine);
				orders.add(bean);
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return orders;
	}

	public synchronized int doRetrieveNprodottiAcquistati(String user) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		int quantity = 0;

		String selectSQL = "SELECT SUM(disponibilit�) as quantita"
				+ " FROM "
				+ TABLE_NAME + " as T1 inner join " + TABLE_NAME2 + " as T2 on "
				+ "T1.numeroOrdine = T2.acquisto where T1.userid= ?";

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setString(1, user);


			ResultSet rs = preparedStatement.executeQuery();

			if(rs.next())
				quantity = rs.getInt("quantita");
		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return quantity;
	}



}
