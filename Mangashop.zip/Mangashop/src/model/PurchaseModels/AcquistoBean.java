package model.PurchaseModels;

import java.sql.Date;
import java.util.ArrayList;

public class AcquistoBean {
	private int numeroOrdine;
	private double prezzo;
	private String stato;
	private String indirizzo;
	private int numCivico;
	private int cap;
	private String citta;
	private String provincia;
	private Date dataOrdine;
	private String userid;
	private ArrayList<ProductBeanCart> prodotti;
	
	//Setter
	public void setNumeroOrdine(int num)
	{
		numeroOrdine=num;
	}
	
	public void setPrezzoAuto()
	{
		prezzo=0;
		for(int i=0; i<prodotti.size(); i++)
		{
			ProductBeanCart v=prodotti.get(i);
			prezzo=prezzo+(v.getPrezzoTotale()*v.getCartQuantity());
		}
	}
	
	public void setNumCivico(int newNCivico)
	{
		numCivico=newNCivico;
	}
	
	public void setCap(int newCap)
	{
		cap=newCap;
	}
	
	public void setCitta(String newCitta)
	{
		citta=newCitta;
	}
	
	public void setProvicia(String newProvincia)
	{
		provincia=newProvincia;
	}
	
	public void setPrezzo(double prezzo)
	{
		this.prezzo=prezzo;
	}
	
	public void setStato(String stato)
	{
		this.stato=stato;
	}
	
	public void setIndirizzo(String ind)
	{
		indirizzo=ind;
	}
	
	public void setDataOrdine(Date data)
	{
		dataOrdine=data;
	}
	
	public void setUtente(String user)
	{
		userid=user;
	}
	
	public void setProdotti(ArrayList<ProductBeanCart> lista)
	{
		prodotti=lista;
	}
	//-------Getter
	public int getNumeroOrdine()
	{
		return numeroOrdine;
	}
	
	public int getNumCivico()
	{
		return numCivico;
	}
	
	public int getCap()
	{
		return cap;
	}
	
	public String getCitta()
	{
		return citta;
	}
	
	public String getProvincia()
	{
		return provincia;
	}
	
	public double getPrezzo()
	{
		return prezzo;
	}
	
	public String getStato()
	{
		return stato;
	}
	
	public String getIndirizzo()
	{
		return indirizzo;
	}
	
	public Date getDataOrdine()
	{
		return dataOrdine;
	}
	
	public String getUtente()
	{
		return userid;
	}
	
	public ArrayList<ProductBeanCart> getProdotti()
	{
		return prodotti;
	}
}
