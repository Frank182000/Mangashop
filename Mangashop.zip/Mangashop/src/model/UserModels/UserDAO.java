package model.UserModels;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;


public class UserDAO 
{
	private static DataSource ds;

	static {
		try {
			Context initCtx = new InitialContext();
			Context envCtx = (Context) initCtx.lookup("java:comp/env");

			ds = (DataSource) envCtx.lookup("jdbc/storage");

		} catch (NamingException e) {
			System.out.println("Error:" + e.getMessage());
		}
	}

	private static final String TABLE_NAME = "cliente";
	
	public static UserBean doRetrieve(UserBean beanInput) 
	{
		
		  Connection connection = null;
	      PreparedStatement preparedStatement = null;
		
	      String userid = beanInput.getUsername();    
	      String passid = beanInput.getPassword();   
		    
	      String searchQuery =
	            "select * from "+TABLE_NAME+" where userid=? and passid=?";
	               
		  
	   
	   UserBean bean = new UserBean();
	   
	   try 
	   {
		   connection=ds.getConnection();
		   preparedStatement=connection.prepareStatement(searchQuery);
		   preparedStatement.setString(1, userid);
		   preparedStatement.setString(2, passid);
		   
		   
		   
		   ResultSet rs = preparedStatement.executeQuery();
		   
		   
		   if(rs.next())
		   {	   
			    bean.setIsValid(true);
			    bean.setUsername(rs.getString("userid"));
			    bean.setPassword(rs.getString("passid"));
				bean.setAdmin(rs.getBoolean("isadmin"));
				bean.setNome(rs.getString("nome"));
				bean.setCognome(rs.getString("cognome"));
				bean.setEmail(rs.getString("email"));
				bean.setTelefono(rs.getString("mobile"));
		   }
		   else
		   {
			   bean.setIsValid(false);
		   }	   
			  
		}  

	   catch (Exception ex) 
	   {
	      System.out.println("Log In failed: An Exception has occurred! " + ex);
	   } 
	   
	   return bean;
	}

	//Metodo per salvare i dati dell'utente al db
	public synchronized void doSave(UserBean user) throws SQLException, Exception
	{

		Connection connection = null;
		PreparedStatement preparedStatement = null;

		String insertSQL = "INSERT INTO " + TABLE_NAME
				+ " (userid, passid, nome, cognome, email, "
				+ "  mobile, isadmin) "
				+ "  VALUES (?, ?, ?, ?, ?, ?, ?)";

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(insertSQL);
			preparedStatement.setString(1, user.getUsername());
			preparedStatement.setString(2, user.getPassword());
			preparedStatement.setString(3, user.getNome());
			preparedStatement.setString(4, user.getCognome());
			preparedStatement.setString(5, user.getEmail());
			preparedStatement.setString(6, user.getTelefono());
			preparedStatement.setBoolean(7, user.getAdmin());

			
			preparedStatement.executeUpdate();


			} 
			finally 
			{
				try 
				{
					if (preparedStatement != null)
						preparedStatement.close();
				} 
				finally 
				{
					if (connection != null)
						connection.close();
				}
			}
	}	

	
	/*
	 * Ritorna l'UserBean se esiste, altrimenti null
	 * */
	public synchronized UserBean doRetrieveByKey(String userid) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		UserBean bean = new UserBean();

		String selectSQL = "SELECT * FROM " +TABLE_NAME + " WHERE userid = ?";

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setString(1, userid);

			ResultSet rs = preparedStatement.executeQuery();

			if (rs.next()) {
				    bean.setUsername(rs.getString("userid"));
				    bean.setPassword(rs.getString("passid"));
				    bean.setNome(rs.getString("name"));
					bean.setCognome(rs.getString("surname"));
				    bean.setEmail(rs.getString("email"));
					bean.setTelefono(rs.getString("mobile"));
					bean.setAdmin(rs.getBoolean("isadmin"));
			}
			else
			{
				return null;
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return bean;
	}

	public synchronized UserBean doRetrieveByKey2(String emailid) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		UserBean bean = new UserBean();

		String selectSQL = "SELECT * FROM " +TABLE_NAME + " WHERE email = ?";

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setString(1, emailid);

			ResultSet rs = preparedStatement.executeQuery();

			if (rs.next()) {
				bean.setUsername(rs.getString("userid"));
			    bean.setPassword(rs.getString("passid"));
			    bean.setNome(rs.getString("name"));
				bean.setCognome(rs.getString("surname"));
			    bean.setEmail(rs.getString("email"));
				bean.setTelefono(rs.getString("mobile"));
				bean.setAdmin(rs.getBoolean("isadmin"));
			}
			else
			{
				return null;
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return bean;
	}
	
	
	 public synchronized boolean doDelete(String userid) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		int result = 0;

		String deleteSQL = "DELETE FROM " + TABLE_NAME + " WHERE userid = ?";

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(deleteSQL);
			preparedStatement.setString(1, userid);

			result = preparedStatement.executeUpdate();

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return (result != 0);
	}

	
	public synchronized ArrayList<UserBean> doRetrieveAll(String order) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		ArrayList<UserBean> username = new ArrayList<UserBean>();

		String selectSQL = "SELECT * FROM " + TABLE_NAME;

		if (order != null && !order.equals("")) {
			selectSQL += " ORDER BY " + order;
		}

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);

			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				UserBean bean = new UserBean();
		
						bean.setUsername(rs.getString("userid"));
					    bean.setPassword(rs.getString("passid"));
					    bean.setNome(rs.getString("name"));
						bean.setCognome(rs.getString("surname"));
					    bean.setEmail(rs.getString("email"));
						bean.setTelefono(rs.getString("mobile"));
						bean.setAdmin(rs.getBoolean("isadmin"));
			username.add(bean);
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return username;
	}
	
	public synchronized void doUpdate(UserBean product) throws SQLException, Exception {

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		String insertSQL = "UPDATE " + TABLE_NAME
				+ " SET userid=?, passid=?, nome=?, cognome=?, email=?,"
				+ " mobile=?, isAdmin=? WHERE userid = ?";

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(insertSQL);
			preparedStatement.setString(1, product.getUsername());
			preparedStatement.setString(2, product.getPassword());
			preparedStatement.setString(3, product.getNome());
			preparedStatement.setString(4, product.getCognome());
			preparedStatement.setString(5, product.getEmail());
			preparedStatement.setString(6, product.getTelefono());
			preparedStatement.setBoolean(7, false);
			preparedStatement.setString(8, product.getUsername());

			preparedStatement.executeUpdate();

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
	}


}

