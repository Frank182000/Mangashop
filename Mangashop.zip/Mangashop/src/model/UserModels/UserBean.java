package model.UserModels;

public class UserBean 
{
	private Boolean isValid;
	private String userid;//primary key
	private String passid;
	private String name;
	private String surname;
	private String mobile;
	private String email;
	private boolean isadmin;
	
	
	//SETS
	public void setIsValid(Boolean isValid) {
		this.isValid = isValid;
	}
	public void setUsername(String userid) {
		this.userid = userid;
	}
	public void setPassword(String password) {
		this.passid = password;
	}
	public void setNome(String nome) {
		this.name = nome;
	}
	public void setCognome(String cognome) {
		this.surname = cognome;
	}
	public void setTelefono(String telefono) {
		this.mobile = telefono;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public void setAdmin(boolean admin)
	{
		isadmin=admin;
	}
	
	
	//GETS
	public Boolean getIsValid() {
		return isValid;
	}
	public String getUsername() {
		return userid;
	}
	public String getPassword() {
		return passid;
	}
	public String getNome() {
		return name;
	}
	public String getCognome() {
		return surname;
	}
	public String getEmail() {
		return email;
	}
	public String getTelefono() {
		return mobile;
	}
	public boolean getAdmin()
	{
		return isadmin;
	}
}
