-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: localhost    Database: nuovomangashop
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `prodotto`
--

DROP TABLE IF EXISTS `prodotto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prodotto` (
  `idProdotto` int NOT NULL AUTO_INCREMENT,
  `disponibilità` int NOT NULL,
  `nomeProdotto` varchar(45) NOT NULL,
  `categoria` varchar(45) NOT NULL,
  `prezzo` float NOT NULL,
  `iva` decimal(3,1) NOT NULL,
  `inCatalogo` tinyint DEFAULT '1',
  `lingua` varchar(45) NOT NULL,
  `descrizione` varchar(800) NOT NULL,
  `dataPubblicazione` date NOT NULL,
  `editore` varchar(45) NOT NULL,
  `numeroVendite` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`idProdotto`),
  UNIQUE KEY `nomeProdotto_UNIQUE` (`nomeProdotto`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prodotto`
--

LOCK TABLES `prodotto` WRITE;
/*!40000 ALTER TABLE `prodotto` DISABLE KEYS */;
INSERT INTO `prodotto` VALUES (1,19,'Demon Slayer 1','Shonen',3.5,19.1,1,'Italiano','Giappone, albori del ventesimo secolo. Il giovane Tanjiro, un gentile venditore di carbone, vede la sua quotidianità stravolta dallo sterminio della famiglia a opera di un demone. L\'unica rimasta in vita è la sorella minore Nezuko, che tuttavia è stata trasformata in un demone a sua volta. Per farla tornare come prima e vendicarsi del mostro che ha ucciso la madre e i fratellini, Tanjiro si mette in viaggio con Nezuko. Ha così inizio questa storia di sangue, spade e avventura!','2019-04-17','Star Comics',4),(2,12,'Hunter x Hunter 10','Shonen',4.2,19.2,1,'Italiano','Il vendicativo Uborghin della Brigata fantasma riesce a rintracciare Kurapika, e inizia così il mortale duello a colpi di Nen, che nel ragazzo sembra particolarmente potente. Nel frattempo, Gon, Killua e Leolio incappano in una nuova asta bandita dalla mafia per uccidere i responsabili del furto dei tesori a York Shin, e intuiscono che si tratta della Brigata Fantasma.','2019-07-11','Panini Comics',38),(3,62,'Jagan 3','Seinen',4.2,19.2,1,'Italiano','Una pioggia di rane scroscia dal cielo. Questi misteriosi parassiti dall\'origine incerta si insidiano negli esseri umani e, basandosi sui desideri repressi nel loro subconscio, li trasformano in mostri ributtanti dalla furia omicida. Jagasaki, un giovane poliziotto di ronda frustrato che fantastica di poter sparare a chiunque, viene \"posseduto\" da un parassita ancora allo stato larvale e, grazie a questo, riesce a mantenere la sua razionalità nonostante il suo corpo cominci a mutare...','2019-01-09','Star Comics',20),(4,12,'Tokyo Ghoul 2','Seinen',5.6,19.0,1,'Italiano','È un mostro che si nutre di cadaveri cacciati nei cimiteri e che, usando la magia nera, assorbe le forze delle sue vittime. Ora questi mostri stanno serpeggiando per le strade di Tokyo. E un adolescente tormentato andrà loro incontro, senza sapere che in questo modo comprometterà definitivamente il proprio destino.','2014-12-03','Starcomics',2),(5,9,'Hunter x Hunter 9','Shonen',9.72,13.0,1,'Italiano','La zia di Gon decide che è arrivato il momento di raccontare al nipotino la verità sul padre che lui è tanto intenzionato a cercare, e gli consegna la scatolina che questi ha lasciato. Gon scopre che contiene un messaggio registrato del padre, un anello e una scheda di memoria. Insieme con Killua, scopre poi che il videogame cui si riferisce la scheda di memoria è \"Greed Island\", un gioco estremamente raro. Per cercarlo, i due si recano all\'asta di Shin York, la più famosa al mondo, dove rincontrano Leolio, che si unisce a loro, e Kurapika, impegnato come guardia del corpo di un\'importante personalità.','2016-09-22','Panini Comics',0),(6,7,'Doraemon 1','Kodomo',6.9,19.0,1,'Italiano','Doraemon è tornato in azione! Con questa nuova edizione a colori che raccoglie una serie di episodi pubblicati originariamente su rivista, il popolarissimo gattone blu e i suoi amici si scateneranno come non mai! Arrivato dal futuro per impedire al giovane Nobita di commettere gli errori di cui i suoi discendenti dovranno altrimenti pagare le conseguenze, Doraemon cerca con i mezzi più disparati e sorprendenti di risollevare le sorti del suo maldestro assistito...','2017-02-22','Star Comics',1),(7,17,'Hunter x Hunter 1','Shonen',4.2,19.0,1,'Italiano','Quattro personaggi tutti a caccia dellambita licenza di Hunter il Cacciatore! Per quanto il loro traguardo sia lo stesso, attraverso i terribili ostacoli incontrati nellesame per ottenere la licenza, Gon, Killua, Kurapica e Leorio diventeranno però ben presto inseparabili!','2020-11-05','Panini Comics',0),(8,3,'Death Note Ryuk','actionFigure',40,22.0,1,'Italiano','Action figure del famoso personaggio Ryuk della serie Death Note.','2018-07-11','ABYstyle',0),(9,6,'Lady Oscar 1','Shojo',4,19.0,1,'Italiano','Francia, XVIII secolo. La Principessa austriaca Maria Antonietta si appresta a conoscere il suo promesso sposo, il futuro Re di Francia Luigi XVI. Ad accompagnarla a quest\'incontro, che cambierà la storia d\'Europa, c\'è l\'avvenente ufficiale Oscar Francois de Jarjayes, che nasconde uno stupefacente segreto...','2015-10-01','RW Edizioni',0),(10,1,'Demon Slayer JP 23','Shonen',10.56,19.0,1,'Giapponese','Volume 23 dell\'opera Demon Slayer, versione in lingua originale giapponese.','2021-09-30','Viz',0),(11,1,'Demon Slayer Tanjiro','actionFigure',69,22.0,1,'Giapponese','Action figure del protagonista della serie Demon Slayer. Spedita dal giappone con scatola originale.','2022-07-02','Viz',1);
/*!40000 ALTER TABLE `prodotto` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-07-09 19:36:53
